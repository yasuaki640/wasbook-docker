<body>
<?php
  $header = $_GET['header'];
  require_once($header . '.php');
?>
本文【省略】
</body>
