<?php
  session_start();
  // ログインチェック（略）
?>
<body>
検索キーワード:<?php echo $_GET['keyword']; ?><BR>
以下略
</body>
