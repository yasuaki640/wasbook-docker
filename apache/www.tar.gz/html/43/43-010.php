<body>
<a href="<?php echo htmlspecialchars($_GET['url']); ?>">ブックマーク</a>
</body>
