<body>
<input type="input" name="mail" value="<?php echo $_GET['p']; ?>">
</body>
