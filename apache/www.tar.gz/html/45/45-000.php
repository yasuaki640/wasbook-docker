<?php
  system('rm /var/www/html/45/img/*');
