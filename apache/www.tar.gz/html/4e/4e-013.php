<?php
  require "4e-012.php";

  $logger = new Logger('test.log');
  $logger->add('test log');
