<?php
  session_start();
?>
<html>
<body>
<form action="46-011.php" method="POST">
ユーザID:<input name="id" type="text"><br>
<input type="submit" value="ログイン">
</form>
</body>
</html>
