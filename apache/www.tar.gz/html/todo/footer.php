<div id="footer">
  <div class="copyright">Bad Todo Ver 1.1.1 &copy; 2018-2024 Hiroshi Tokumaru</div>
</div><!-- /#footer-->
