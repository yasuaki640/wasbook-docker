<?php
  require_once './common.php';
  header('Location: todolist.php');
