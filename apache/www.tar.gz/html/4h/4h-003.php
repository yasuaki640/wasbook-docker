<?php
  header('Content-Type: image/gif');
  error_log($_SERVER['QUERY_STRING']);
  echo base64_decode('R0lGODlhAQABAIgAAP///wAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==');
