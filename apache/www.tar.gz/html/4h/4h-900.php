<?php
  header('Access-Control-Allow-Origin: http://example.jp');
?><img src=/ onerror=alert(document.domain) >
